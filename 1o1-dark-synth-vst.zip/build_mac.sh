#!/usr/bin/env bash
# ============================================================
# 1o1 DARK SYNTH - macOS build script (VST3 + AU)
# Requirements: Xcode command line tools + CMake
#   xcode-select --install
#   brew install cmake
# ============================================================
set -e
cd "$(dirname "$0")"

echo "==> Configuring (this downloads JUCE the first time)..."
cmake -B build -G "Xcode" -DCMAKE_OSX_ARCHITECTURES="arm64;x86_64" -DCOPY_AFTER_BUILD=ON

echo "==> Building Release..."
cmake --build build --config Release

echo ""
echo "DONE. Plugins were auto-copied to:"
echo "  VST3 : ~/Library/Audio/Plug-Ins/VST3/1o1 DARK SYNTH.vst3"
echo "  AU   : ~/Library/Audio/Plug-Ins/Components/1o1 DARK SYNTH.component"
echo ""
echo "In FL Studio: Options > Manage Plugins > Find plugins, then it appears under 1o1 Audio."
