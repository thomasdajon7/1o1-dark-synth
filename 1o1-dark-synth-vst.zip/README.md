# 1o1 DARK SYNTH — Native Plugin (VST3 / AU)

**STEAM Engine™ Software Synthesis Technology**

A real, installable synthesizer plugin for **FL Studio, Ableton, Logic, Cubase, Reaper** and any VST3/AU host, on **Windows and macOS**. Three synthesis engines — **Subtractive, FM, and Wavetable** — with multimode filter, ADSR, and a drive/delay/reverb FX chain. Built with the [JUCE 8](https://juce.com) framework.

> ✅ **Compile-verified:** this exact source has been built successfully into a working VST3 (via the `make` generator). If it builds for us, it builds for you.

---

## Fastest path: get ready-made binaries from CI (no local tools needed)

This kit ships with a **GitHub Actions** workflow (`.github/workflows/build.yml`) that compiles **Windows VST3**, **macOS VST3 + AU**, and **Linux VST3** automatically:

1. Create a new GitHub repo and push this `vst-native` folder to it (use the **"Save to GitHub"** button in Emergent, or `git`).
2. Open the repo's **Actions** tab → the *Build 1o1 DARK SYNTH* workflow runs on push (or click **Run workflow**).
3. When it finishes, download the compiled plugins from the run's **Artifacts** section, **or** from the auto-published **latest release** via these permanent URLs:
   - `https://github.com/OWNER/REPO/releases/latest/download/1o1-DARK-SYNTH-Windows.zip`
   - `https://github.com/OWNER/REPO/releases/latest/download/1o1-DARK-SYNTH-macOS.zip`
   (These are exactly the links the in-app plugin modal builds once you enter your `owner/repo`.)
4. Drop the `.vst3` into your VST3 folder (see below) and rescan in FL Studio.

---

## Build it yourself

### Choose your build tool (CMake generator)
| Platform | Command | Generator |
|---|---|---|
| Linux / macOS | `./build_make.sh` | **Unix Makefiles (make)** ✅ verified |
| macOS (Xcode) | `./build_mac.sh` | Xcode |
| Windows | `build_windows.bat` | Visual Studio 2022 |

You can always pick the generator explicitly:
```bash
cmake -B build -G "Unix Makefiles" -DCMAKE_BUILD_TYPE=Release   # make
cmake -B build -G "Xcode"                                        # macOS Xcode
cmake -B build -G "Visual Studio 17 2022" -A x64                 # Windows
cmake --build build --config Release
```

### One-time prerequisites
- **Linux:** `sudo apt-get install cmake build-essential libasound2-dev libfreetype6-dev libfontconfig1-dev libx11-dev libxcomposite-dev libxcursor-dev libxext-dev libxinerama-dev libxrandr-dev libxrender-dev libglu1-mesa-dev`
- **macOS:** `xcode-select --install` and `brew install cmake`
- **Windows:** Visual Studio 2022 (*Desktop development with C++*) + [CMake](https://cmake.org/download/) (add to PATH)

JUCE is downloaded automatically — no manual setup.

---

## Install into FL Studio
- **Windows:** copy `build\1o1DarkSynth_artefacts\Release\VST3\1o1 DARK SYNTH.vst3` → `C:\Program Files\Common Files\VST3\`
- **macOS:** `build_mac.sh` auto-installs to `~/Library/Audio/Plug-Ins/VST3` (and AU to `.../Components`)

Then in FL Studio: **Options → Manage Plugins → Find installed plugins**. It appears under manufacturer **"1o1 Audio"** as **1o1 DARK SYNTH**.

---

## Project layout
```
CMakeLists.txt              # JUCE plugin definition (fetches JUCE 8)
Source/
  PluginProcessor.*         # DSP: 16-voice synth + FX chain + parameters
  PluginEditor.*            # Dark studio UI (knobs + engine/filter selectors)
  SynthVoice.h              # Subtractive / FM / Wavetable voice
build_make.sh               # build with make  (verified)
build_mac.sh                # build with Xcode
build_windows.bat           # build with Visual Studio 2022
.github/workflows/build.yml # CI: auto-build Win/Mac/Linux binaries
```

## Troubleshooting
- **"ft2build.h not found" (Linux)** → install `libfreetype6-dev` **and** `libfontconfig1-dev` (JUCE needs both).
- **"CMake not found"** → reinstall CMake, enable *Add to PATH*, reopen the terminal.
- **First build is slow** → it clones JUCE once; later builds are fast.
- **FL Studio doesn't see it** → confirm the `.vst3` is in the VST3 folder and re-run *Find installed plugins*.
