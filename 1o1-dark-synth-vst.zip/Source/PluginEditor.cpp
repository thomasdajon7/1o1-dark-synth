#include "PluginEditor.h"

static const juce::Colour kBg      { 0xff0a0a0a };
static const juce::Colour kPanel   { 0xff141414 };
static const juce::Colour kAccent  { 0xffff5500 };
static const juce::Colour kCyan    { 0xff00f0ff };
static const juce::Colour kText    { 0xfff5f5f5 };

DarkSynthEditor::Ctl& DarkSynthEditor::addKnob (const juce::String& id, const juce::String& name)
{
    auto* c = new Ctl();
    c->slider.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    c->slider.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 62, 16);
    c->slider.setColour (juce::Slider::rotarySliderFillColourId, kAccent);
    c->slider.setColour (juce::Slider::rotarySliderOutlineColourId, juce::Colour (0xff2a2a2a));
    c->slider.setColour (juce::Slider::thumbColourId, kAccent);
    c->slider.setColour (juce::Slider::textBoxTextColourId, kCyan);
    c->slider.setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
    addAndMakeVisible (c->slider);

    c->label.setText (name, juce::dontSendNotification);
    c->label.setJustificationType (juce::Justification::centred);
    c->label.setColour (juce::Label::textColourId, juce::Colour (0xff8c8c8c));
    c->label.setFont (juce::Font (10.0f, juce::Font::bold));
    addAndMakeVisible (c->label);

    c->att = std::make_unique<SliderAtt> (proc.apvts, id, c->slider);
    knobs.add (c);
    return *c;
}

DarkSynthEditor::DarkSynthEditor (DarkSynthProcessor& p)
    : AudioProcessorEditor (&p), proc (p)
{
    auto setupCombo = [this] (juce::ComboBox& box, const juce::StringArray& items)
    {
        box.addItemList (items, 1);
        box.setColour (juce::ComboBox::backgroundColourId, juce::Colour (0xff050505));
        box.setColour (juce::ComboBox::textColourId, kText);
        box.setColour (juce::ComboBox::outlineColourId, juce::Colour (0xff2a2a2a));
        addAndMakeVisible (box);
    };

    setupCombo (engineBox, { "Subtractive", "FM", "Wavetable" });
    setupCombo (osc1Box,   { "Sine", "Saw", "Square", "Triangle" });
    setupCombo (osc2Box,   { "Sine", "Saw", "Square", "Triangle" });
    setupCombo (filterBox, { "LowPass", "HighPass", "BandPass" });

    engineAtt = std::make_unique<ComboAtt> (proc.apvts, "engine", engineBox);
    osc1Att   = std::make_unique<ComboAtt> (proc.apvts, "osc1Wave", osc1Box);
    osc2Att   = std::make_unique<ComboAtt> (proc.apvts, "osc2Wave", osc2Box);
    filterAtt = std::make_unique<ComboAtt> (proc.apvts, "filterType", filterBox);

    addKnob ("osc1Detune", "DET 1");
    addKnob ("osc2Detune", "DET 2");
    addKnob ("oscMix",     "MIX");
    addKnob ("fmRatio",    "RATIO");
    addKnob ("fmIndex",    "INDEX");
    addKnob ("wavePos",    "WAVE");
    addKnob ("cutoff",     "CUTOFF");
    addKnob ("resonance",  "RESO");
    addKnob ("attack",     "ATK");
    addKnob ("decay",      "DEC");
    addKnob ("sustain",    "SUS");
    addKnob ("release",    "REL");
    addKnob ("drive",      "DRIVE");
    addKnob ("delayMix",   "DLY MIX");
    addKnob ("delayTime",  "DLY TIME");
    addKnob ("delayFeedback", "DLY FBK");
    addKnob ("reverbMix",  "VERB");
    addKnob ("master",     "MASTER");

    setSize (760, 460);
}

void DarkSynthEditor::paint (juce::Graphics& g)
{
    g.fillAll (kBg);
    g.setColour (kPanel);
    g.fillRoundedRectangle (getLocalBounds().reduced (8).toFloat(), 10.0f);

    g.setColour (kText);
    g.setFont (juce::Font (26.0f, juce::Font::bold));
    g.drawText ("1o1 DARK SYNTH", 24, 14, 400, 30, juce::Justification::left);
    g.setColour (kAccent);
    g.setFont (juce::Font (26.0f, juce::Font::bold));
    g.drawText ("1o1", 24, 14, 44, 30, juce::Justification::left);

    g.setColour (juce::Colour (0xff525252));
    g.setFont (juce::Font (10.0f));
    g.drawText ("STEAM Engine\u2122 Software Synthesis", 24, 44, 400, 16, juce::Justification::left);
}

void DarkSynthEditor::resized()
{
    auto area = getLocalBounds().reduced (24);
    area.removeFromTop (60);

    auto comboRow = area.removeFromTop (34);
    engineBox.setBounds (comboRow.removeFromLeft (150).reduced (2));
    comboRow.removeFromLeft (10);
    osc1Box.setBounds (comboRow.removeFromLeft (120).reduced (2));
    osc2Box.setBounds (comboRow.removeFromLeft (120).reduced (2));
    filterBox.setBounds (comboRow.removeFromLeft (120).reduced (2));

    area.removeFromTop (14);

    // grid of knobs: 6 per row
    const int perRow = 6;
    const int kw = area.getWidth() / perRow;
    const int kh = 110;
    for (int i = 0; i < knobs.size(); ++i)
    {
        int row = i / perRow, col = i % perRow;
        juce::Rectangle<int> cell (area.getX() + col * kw, area.getY() + row * kh, kw, kh);
        knobs[i]->label.setBounds (cell.removeFromTop (16));
        knobs[i]->slider.setBounds (cell.reduced (6));
    }
}
