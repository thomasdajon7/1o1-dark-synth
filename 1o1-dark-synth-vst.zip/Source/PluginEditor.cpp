#include "PluginEditor.h"

// ---- Nexus palette ----
static const juce::Colour kBgTop   { 0xffeef1f5 };
static const juce::Colour kBgBot   { 0xffcfd5dd };
static const juce::Colour kPanel   { 0xfff8fafc };
static const juce::Colour kPanelEd { 0xffbcc4cd };
static const juce::Colour kAccent  { 0xff1f8ecd };
static const juce::Colour kAccentD { 0xff0f5f88 };
static const juce::Colour kKnobHi  { 0xfffdfefe };
static const juce::Colour kKnobLo  { 0xffdae0e7 };
static const juce::Colour kTrack   { 0xffc6ccd4 };
static const juce::Colour kText    { 0xff33404b };
static const juce::Colour kMuted   { 0xff8a97a3 };
static const juce::Colour kLcdBg   { 0xff072433 };
static const juce::Colour kLcdTxt  { 0xff7fe3ff };
static const juce::Colour kLcdSel  { 0xff1f8ecd };

// ---- built-in presets ----
struct FactoryPreset { juce::String name, cat; std::vector<std::pair<juce::String,float>> p; };

static const std::vector<FactoryPreset>& presets()
{
    static const std::vector<FactoryPreset> P = {
        { "LD Saw Init", "Lead",  {{"engine",0},{"osc1Wave",1},{"osc2Wave",1},{"filterType",0},{"cutoff",4200},{"resonance",3},{"attack",0.01f},{"decay",0.3f},{"sustain",0.7f},{"release",0.3f},{"drive",0.1f},{"master",0.7f}} },
        { "Super Saw",   "Lead",  {{"engine",0},{"osc1Wave",1},{"osc2Wave",1},{"osc1Detune",-7},{"osc2Detune",7},{"cutoff",4200},{"resonance",3},{"delayMix",0.25f},{"reverbMix",0.3f},{"master",0.68f}} },
        { "Square Lead", "Lead",  {{"engine",0},{"osc1Wave",2},{"osc2Wave",2},{"osc2Detune",-12},{"cutoff",3600},{"resonance",4},{"drive",0.15f},{"master",0.7f}} },
        { "Acid Lead",   "Lead",  {{"engine",0},{"osc1Wave",1},{"osc2Wave",2},{"cutoff",900},{"resonance",12},{"decay",0.15f},{"sustain",0.3f},{"drive",0.25f},{"master",0.7f}} },
        { "Sub Bass",    "Bass",  {{"engine",0},{"osc1Wave",0},{"osc2Wave",3},{"cutoff",600},{"resonance",2},{"sustain",0.8f},{"master",0.75f}} },
        { "Reese Bass",  "Bass",  {{"engine",0},{"osc1Wave",1},{"osc2Wave",1},{"osc1Detune",-12},{"osc2Detune",-19},{"cutoff",1200},{"resonance",5},{"drive",0.3f},{"master",0.72f}} },
        { "Growl Bass",  "Bass",  {{"engine",1},{"fmRatio",2},{"fmIndex",6},{"cutoff",800},{"resonance",6},{"drive",0.35f},{"master",0.72f}} },
        { "Warm Pad",    "Pad",   {{"engine",0},{"osc1Wave",1},{"osc2Wave",1},{"osc1Detune",-5},{"osc2Detune",7},{"cutoff",1600},{"attack",1.2f},{"release",1.8f},{"sustain",0.85f},{"reverbMix",0.6f},{"master",0.62f}} },
        { "Choir Pad",   "Pad",   {{"engine",0},{"osc1Wave",3},{"osc2Wave",1},{"osc1Detune",-4},{"osc2Detune",4},{"cutoff",1400},{"attack",0.9f},{"release",1.5f},{"sustain",0.9f},{"reverbMix",0.6f},{"master",0.62f}} },
        { "Dream Pad",   "Pad",   {{"engine",2},{"wavePos",0.4f},{"osc1Detune",-5},{"osc2Detune",7},{"cutoff",1600},{"attack",1.2f},{"release",1.8f},{"reverbMix",0.65f},{"master",0.62f}} },
        { "Electric Piano","Keys",{{"engine",1},{"fmRatio",1},{"fmIndex",5},{"attack",0.005f},{"decay",0.6f},{"sustain",0.25f},{"release",0.5f},{"reverbMix",0.25f},{"master",0.72f}} },
        { "Soft Keys",   "Keys",  {{"engine",2},{"wavePos",0.25f},{"osc2Detune",5},{"cutoff",3200},{"attack",0.01f},{"decay",0.5f},{"sustain",0.4f},{"release",0.7f},{"reverbMix",0.35f},{"master",0.7f}} },
        { "Crystal Bell","Bells", {{"engine",1},{"fmRatio",5},{"fmIndex",9},{"filterType",1},{"cutoff",400},{"decay",1.8f},{"sustain",0.05f},{"release",1.4f},{"reverbMix",0.55f},{"master",0.68f}} },
        { "Tubular Bells","Bells",{{"engine",1},{"fmRatio",7},{"fmIndex",7},{"filterType",2},{"cutoff",2200},{"decay",2.4f},{"sustain",0.0f},{"release",1.8f},{"reverbMix",0.6f},{"master",0.66f}} },
        { "Nylon Pluck", "Pluck", {{"engine",2},{"wavePos",0.15f},{"osc1Wave",3},{"cutoff",3000},{"resonance",3},{"decay",0.35f},{"sustain",0.0f},{"release",0.25f},{"reverbMix",0.3f},{"master",0.7f}} },
        { "Arp Pluck",   "Arp",   {{"engine",0},{"osc1Wave",1},{"osc2Wave",2},{"osc2Detune",7},{"cutoff",2600},{"resonance",6},{"decay",0.22f},{"sustain",0.0f},{"delayMix",0.28f},{"delayTime",0.1875f},{"delayFeedback",0.45f},{"master",0.7f}} },
        { "Trance Arp",  "Arp",   {{"engine",0},{"osc1Wave",1},{"osc2Wave",1},{"osc1Detune",-3},{"osc2Detune",3},{"cutoff",3200},{"resonance",8},{"decay",0.18f},{"delayMix",0.3f},{"delayTime",0.125f},{"delayFeedback",0.5f},{"master",0.68f}} },
    };
    return P;
}

// ================= LookAndFeel =================
NexusLookAndFeel::NexusLookAndFeel()
{
    setColour (juce::Slider::textBoxTextColourId, kAccentD);
    setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
    setColour (juce::PopupMenu::backgroundColourId, kLcdBg);
    setColour (juce::PopupMenu::textColourId, kLcdTxt);
    setColour (juce::PopupMenu::highlightedBackgroundColourId, kAccent);
}
juce::Font NexusLookAndFeel::getComboBoxFont (juce::ComboBox&) { return juce::Font (juce::Font::getDefaultMonospacedFontName(), 12.5f, juce::Font::bold); }
juce::Font NexusLookAndFeel::getLabelFont (juce::Label&) { return juce::Font (9.5f, juce::Font::bold); }

void NexusLookAndFeel::drawRotarySlider (juce::Graphics& g, int x, int y, int w, int h,
                                         float pos, float startAngle, float endAngle, juce::Slider&)
{
    auto b = juce::Rectangle<float> ((float) x, (float) y, (float) w, (float) h).reduced (5.0f);
    auto radius = juce::jmin (b.getWidth(), b.getHeight()) * 0.5f;
    auto cx = b.getCentreX(), cy = b.getCentreY();
    auto angle = startAngle + pos * (endAngle - startAngle);
    auto rInner = radius * 0.6f;

    g.setColour (juce::Colours::black.withAlpha (0.12f));
    g.fillEllipse (cx - rInner, cy - rInner + 2.0f, rInner * 2.0f, rInner * 2.0f);
    juce::ColourGradient grad (kKnobHi, cx, cy - rInner, kKnobLo, cx, cy + rInner, false);
    g.setGradientFill (grad);
    g.fillEllipse (cx - rInner, cy - rInner, rInner * 2.0f, rInner * 2.0f);
    g.setColour (kPanelEd);
    g.drawEllipse (cx - rInner, cy - rInner, rInner * 2.0f, rInner * 2.0f, 1.0f);

    juce::Path track; track.addCentredArc (cx, cy, radius, radius, 0.0f, startAngle, endAngle, true);
    g.setColour (kTrack);
    g.strokePath (track, juce::PathStrokeType (2.6f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    juce::Path val; val.addCentredArc (cx, cy, radius, radius, 0.0f, startAngle, angle, true);
    g.setColour (kAccent);
    g.strokePath (val, juce::PathStrokeType (2.6f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

    juce::Path ptr; auto pl = rInner * 0.88f;
    ptr.startNewSubPath (cx, cy);
    ptr.lineTo (cx + pl * std::cos (angle - juce::MathConstants<float>::halfPi),
                cy + pl * std::sin (angle - juce::MathConstants<float>::halfPi));
    g.setColour (kAccentD);
    g.strokePath (ptr, juce::PathStrokeType (2.2f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    g.setColour (kAccent);
    g.fillEllipse (cx - 2.6f, cy - 2.6f, 5.2f, 5.2f);
}

void NexusLookAndFeel::drawComboBox (juce::Graphics& g, int width, int height, bool,
                                     int, int, int, int, juce::ComboBox&)
{
    auto b = juce::Rectangle<float> (0, 0, (float) width, (float) height);
    g.setColour (kLcdBg); g.fillRoundedRectangle (b, 5.0f);
    g.setColour (kAccent.withAlpha (0.7f)); g.drawRoundedRectangle (b.reduced (0.5f), 5.0f, 1.0f);
    juce::Path tri; float cxp = width - 13.0f, cyp = height * 0.5f;
    tri.addTriangle (cxp, cyp + 3.0f, cxp + 6.0f, cyp - 3.0f, cxp - 6.0f, cyp - 3.0f);
    g.setColour (kLcdTxt.withAlpha (0.8f)); g.fillPath (tri);
}

// ================= List model =================
void LcdListModel::paintListBoxItem (int row, juce::Graphics& g, int w, int h, bool sel)
{
    if (! rowText) return;
    if (sel) { g.setColour (kLcdSel); g.fillRect (0, 0, w, h); g.setColour (juce::Colours::white); }
    else g.setColour (kLcdTxt);
    g.setFont (juce::Font (juce::Font::getDefaultMonospacedFontName(), 12.0f, juce::Font::plain));
    g.drawText (rowText (row), 8, 0, w - 10, h, juce::Justification::centredLeft);
}

// ================= Editor =================
void DarkSynthEditor::addKnob (const juce::String& id, const juce::String& name)
{
    auto* c = new Ctl();
    c->slider.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    c->slider.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 58, 15);
    c->slider.setColour (juce::Slider::textBoxTextColourId, kAccentD);
    c->slider.setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
    c->slider.setLookAndFeel (&lnf);
    addAndMakeVisible (c->slider);
    c->label.setText (name, juce::dontSendNotification);
    c->label.setJustificationType (juce::Justification::centred);
    c->label.setColour (juce::Label::textColourId, kMuted);
    c->label.setLookAndFeel (&lnf);
    addAndMakeVisible (c->label);
    c->att = std::make_unique<SliderAtt> (proc.apvts, id, c->slider);
    knobs.add (c);
}

void DarkSynthEditor::setParam (const juce::String& id, float actual)
{
    if (auto* p = proc.apvts.getParameter (id))
        p->setValueNotifyingHost (p->convertTo0to1 (actual));
}

void DarkSynthEditor::rebuildFiltered()
{
    filtered.clear();
    const auto& all = presets();
    for (int i = 0; i < (int) all.size(); ++i)
        if (all[(size_t) i].cat == categories[selectedCat])
            filtered.add (i);
    presetBox.updateContent();
    presetBox.deselectAllRows();
    repaint();
}

void DarkSynthEditor::applyPreset (int filteredRow)
{
    if (filteredRow < 0 || filteredRow >= filtered.size()) return;
    const auto& pr = presets()[(size_t) filtered[filteredRow]];
    // reset a baseline so unspecified params return to sane defaults
    for (auto& kv : pr.p) setParam (kv.first, kv.second);
    currentPresetName = pr.name;
    repaint();
}

DarkSynthEditor::DarkSynthEditor (DarkSynthProcessor& p)
    : AudioProcessorEditor (&p), proc (p)
{
    setLookAndFeel (&lnf);

    auto setupCombo = [this] (juce::ComboBox& box, const juce::StringArray& items)
    {
        box.addItemList (items, 1);
        box.setColour (juce::ComboBox::backgroundColourId, kLcdBg);
        box.setColour (juce::ComboBox::textColourId, kLcdTxt);
        box.setColour (juce::ComboBox::outlineColourId, kAccent);
        box.setColour (juce::ComboBox::arrowColourId, kLcdTxt);
        box.setLookAndFeel (&lnf);
        addAndMakeVisible (box);
    };
    setupCombo (engineBox, { "Subtractive", "FM", "Wavetable" });
    setupCombo (osc1Box,   { "Sine", "Saw", "Square", "Triangle" });
    setupCombo (osc2Box,   { "Sine", "Saw", "Square", "Triangle" });
    setupCombo (filterBox, { "LowPass", "HighPass", "BandPass" });
    engineAtt = std::make_unique<ComboAtt> (proc.apvts, "engine", engineBox);
    osc1Att   = std::make_unique<ComboAtt> (proc.apvts, "osc1Wave", osc1Box);
    osc2Att   = std::make_unique<ComboAtt> (proc.apvts, "osc2Wave", osc2Box);
    filterAtt = std::make_unique<ComboAtt> (proc.apvts, "filterType", filterBox);

    // FILTER MODIFIER
    addKnob ("cutoff", "CUTOFF"); addKnob ("resonance", "RESO");
    // OSCILLATOR
    addKnob ("osc1Detune", "DET 1"); addKnob ("osc2Detune", "DET 2");
    addKnob ("oscMix", "MIX"); addKnob ("wavePos", "WAVE");
    // AMP MODIFIER
    addKnob ("attack", "ATK"); addKnob ("decay", "DEC");
    addKnob ("sustain", "SUS"); addKnob ("release", "REL");
    // FM
    addKnob ("fmRatio", "RATIO"); addKnob ("fmIndex", "INDEX");
    // BOTTOM
    addKnob ("drive", "DRIVE"); addKnob ("delayMix", "DLY MIX");
    addKnob ("delayTime", "DLY TIME"); addKnob ("delayFeedback", "DLY FBK");
    addKnob ("reverbMix", "VERB"); addKnob ("master", "MASTER");

    // categories
    for (auto& pr : presets())
        if (! categories.contains (pr.cat)) categories.add (pr.cat);

    catModel.numRows = [this] { return categories.size(); };
    catModel.rowText = [this] (int r) { return categories[r]; };
    catModel.onSelect = [this] (int r) { if (r >= 0 && r < categories.size()) { selectedCat = r; catBox.selectRow (r); rebuildFiltered(); } };
    catBox.setModel (&catModel);
    catBox.setColour (juce::ListBox::backgroundColourId, kLcdBg);
    catBox.setRowHeight (22);
    addAndMakeVisible (catBox);

    presetModel.numRows = [this] { return filtered.size(); };
    presetModel.rowText = [this] (int r) { return (r >= 0 && r < filtered.size()) ? presets()[(size_t) filtered[r]].name : juce::String(); };
    presetModel.onSelect = [this] (int r) { presetBox.selectRow (r); applyPreset (r); };
    presetBox.setModel (&presetModel);
    presetBox.setColour (juce::ListBox::backgroundColourId, kLcdBg);
    presetBox.setRowHeight (22);
    addAndMakeVisible (presetBox);

    catBox.selectRow (0);
    rebuildFiltered();

    setSize (940, 650);
}

DarkSynthEditor::~DarkSynthEditor()
{
    for (auto* c : knobs) { c->slider.setLookAndFeel (nullptr); c->label.setLookAndFeel (nullptr); }
    engineBox.setLookAndFeel (nullptr); osc1Box.setLookAndFeel (nullptr);
    osc2Box.setLookAndFeel (nullptr); filterBox.setLookAndFeel (nullptr);
    catBox.setModel (nullptr); presetBox.setModel (nullptr);
    setLookAndFeel (nullptr);
}

static void drawPanel (juce::Graphics& g, juce::Rectangle<int> r, const juce::String& title)
{
    auto rf = r.toFloat();
    g.setColour (juce::Colours::white.withAlpha (0.6f));
    g.fillRoundedRectangle (rf, 9.0f);
    g.setColour (kPanelEd);
    g.drawRoundedRectangle (rf.reduced (0.5f), 9.0f, 1.0f);
    g.setColour (kAccent);
    g.setFont (juce::Font (9.5f, juce::Font::bold));
    g.drawText (title, r.getX() + 12, r.getY() + 6, r.getWidth() - 20, 12, juce::Justification::left);
}

void DarkSynthEditor::paint (juce::Graphics& g)
{
    g.setGradientFill (juce::ColourGradient (kBgTop, 0, 0, kBgBot, 0, (float) getHeight(), false));
    g.fillAll();
    auto chassis = getLocalBounds().reduced (7).toFloat();
    g.setColour (kPanel); g.fillRoundedRectangle (chassis, 16.0f);
    g.setColour (kPanelEd); g.drawRoundedRectangle (chassis.reduced (0.5f), 16.0f, 1.4f);

    // screws
    g.setColour (kPanelEd.withAlpha (0.7f));
    for (auto pt : { juce::Point<float> (24, 24), { (float) getWidth() - 24, 24.0f },
                     { 24.0f, (float) getHeight() - 24 }, { (float) getWidth() - 24, (float) getHeight() - 24 } })
        g.fillEllipse (pt.x - 4, pt.y - 4, 8, 8);

    // title
    g.setColour (kText); g.setFont (juce::Font (24.0f, juce::Font::bold));
    g.drawText (" o1 DARK SYNTH", 40, 16, 400, 30, juce::Justification::left);
    g.setColour (kAccent); g.setFont (juce::Font (24.0f, juce::Font::bold));
    g.drawText ("1", 40, 16, 20, 30, juce::Justification::left);
    g.setFont (juce::Font (12.0f, juce::Font::bold));
    g.drawText (juce::String::fromUTF8 ("\xC2\xB2"), 258, 14, 16, 16, juce::Justification::left);

    // panels
    drawPanel (g, rFilter, "FILTER MODIFIER");
    drawPanel (g, rOsc,    "OSCILLATOR");
    drawPanel (g, rAmp,    "AMP MODIFIER");
    drawPanel (g, rFm,     "FM ENGINE");
    drawPanel (g, rBottom, "MASTER \xC2\xB7 FX \xC2\xB7 OUTPUT");

    // LCD frame
    auto lf = rLcd.toFloat();
    g.setColour (juce::Colours::black.withAlpha (0.25f));
    g.fillRoundedRectangle (lf.expanded (4.0f), 10.0f);
    g.setColour (kLcdBg); g.fillRoundedRectangle (lf, 8.0f);
    g.setColour (kAccent); g.drawRoundedRectangle (lf.reduced (0.5f), 8.0f, 1.2f);
    // LCD header (current preset)
    g.setColour (kLcdTxt); g.setFont (juce::Font (juce::Font::getDefaultMonospacedFontName(), 15.0f, juce::Font::bold));
    g.drawText (currentPresetName, rLcd.getX() + 12, rLcd.getY() + 8, rLcd.getWidth() - 24, 20, juce::Justification::centredLeft);
    g.setColour (kAccent.withAlpha (0.4f));
    g.drawHorizontalLine (rLcd.getY() + 32, (float) rLcd.getX() + 8, (float) rLcd.getRight() - 8);
}

void DarkSynthEditor::layoutKnobs (juce::Rectangle<int> area, int start, int count, int cols)
{
    area.removeFromTop (20); // panel title space
    const int rows = (count + cols - 1) / cols;
    const int cw = area.getWidth() / cols;
    const int ch = area.getHeight() / rows;
    for (int i = 0; i < count; ++i)
    {
        int idx = start + i, r = i / cols, c = i % cols;
        juce::Rectangle<int> cell (area.getX() + c * cw, area.getY() + r * ch, cw, ch);
        knobs[idx]->label.setBounds (cell.removeFromTop (13));
        knobs[idx]->slider.setBounds (cell.reduced (5));
    }
}

void DarkSynthEditor::resized()
{
    auto area = getLocalBounds().reduced (24);
    area.removeFromTop (34); // header

    auto comboRow = area.removeFromTop (30);
    engineBox.setBounds (comboRow.removeFromLeft (200).reduced (2));
    comboRow.removeFromLeft (8);
    osc1Box.setBounds (comboRow.removeFromLeft (150).reduced (2));
    osc2Box.setBounds (comboRow.removeFromLeft (150).reduced (2));
    filterBox.setBounds (comboRow.removeFromLeft (150).reduced (2));
    area.removeFromTop (10);

    auto bottom = area.removeFromBottom (150);
    rBottom = bottom;
    area.removeFromBottom (12);

    const int sideW = 268;
    auto left = area.removeFromLeft (sideW);
    auto right = area.removeFromRight (sideW);
    area.removeFromLeft (14); area.removeFromRight (14);
    rLcd = area;

    rFilter = left.removeFromTop (138);
    left.removeFromTop (10);
    rOsc = left;

    rAmp = right.removeFromTop (208);
    right.removeFromTop (10);
    rFm = right;

    layoutKnobs (rFilter, 0, 2, 2);
    layoutKnobs (rOsc,    2, 4, 2);
    layoutKnobs (rAmp,    6, 4, 2);
    layoutKnobs (rFm,    10, 2, 2);
    layoutKnobs (rBottom,12, 6, 6);

    auto lcd = rLcd.reduced (10);
    lcd.removeFromTop (30); // header line
    auto cat = lcd.removeFromLeft (96);
    lcd.removeFromLeft (6);
    catBox.setBounds (cat);
    presetBox.setBounds (lcd);
}
