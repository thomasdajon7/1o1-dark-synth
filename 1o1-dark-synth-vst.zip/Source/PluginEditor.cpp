#include "PluginEditor.h"

// ---- Nexus palette (white glossy hardware) ----
static const juce::Colour kBgTop   { 0xffeef1f5 };
static const juce::Colour kBgBot   { 0xffd9dee5 };
static const juce::Colour kPanel   { 0xfff8fafc };
static const juce::Colour kPanelEd { 0xffc6cdd5 };
static const juce::Colour kAccent  { 0xff1f8ecd };
static const juce::Colour kAccentD { 0xff0f5f88 };
static const juce::Colour kKnobHi  { 0xfffdfefe };
static const juce::Colour kKnobLo  { 0xffdde3ea };
static const juce::Colour kTrack   { 0xffcbd1d9 };
static const juce::Colour kText    { 0xff33404b };
static const juce::Colour kMuted   { 0xff8a97a3 };
static const juce::Colour kLcdBg   { 0xff08283a };
static const juce::Colour kLcdTxt  { 0xff7fe3ff };

NexusLookAndFeel::NexusLookAndFeel()
{
    setColour (juce::Slider::textBoxTextColourId, kAccentD);
    setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
    setColour (juce::PopupMenu::backgroundColourId, kLcdBg);
    setColour (juce::PopupMenu::textColourId, kLcdTxt);
    setColour (juce::PopupMenu::highlightedBackgroundColourId, kAccent);
}

juce::Font NexusLookAndFeel::getComboBoxFont (juce::ComboBox&)
{
    return juce::Font (juce::Font::getDefaultMonospacedFontName(), 13.0f, juce::Font::bold);
}

juce::Font NexusLookAndFeel::getLabelFont (juce::Label&)
{
    return juce::Font (10.0f, juce::Font::bold);
}

void NexusLookAndFeel::drawRotarySlider (juce::Graphics& g, int x, int y, int w, int h,
                                         float pos, float startAngle, float endAngle,
                                         juce::Slider&)
{
    auto bounds = juce::Rectangle<float> ((float) x, (float) y, (float) w, (float) h).reduced (6.0f);
    auto radius = juce::jmin (bounds.getWidth(), bounds.getHeight()) * 0.5f;
    auto cx = bounds.getCentreX();
    auto cy = bounds.getCentreY();
    auto angle = startAngle + pos * (endAngle - startAngle);
    auto rInner = radius * 0.62f;

    // soft drop shadow
    g.setColour (juce::Colours::black.withAlpha (0.12f));
    g.fillEllipse (cx - rInner, cy - rInner + 2.0f, rInner * 2.0f, rInner * 2.0f);

    // knob body (glossy light gradient)
    juce::ColourGradient grad (kKnobHi, cx, cy - rInner, kKnobLo, cx, cy + rInner, false);
    g.setGradientFill (grad);
    g.fillEllipse (cx - rInner, cy - rInner, rInner * 2.0f, rInner * 2.0f);
    g.setColour (kPanelEd);
    g.drawEllipse (cx - rInner, cy - rInner, rInner * 2.0f, rInner * 2.0f, 1.0f);

    // background track
    juce::Path track;
    track.addCentredArc (cx, cy, radius, radius, 0.0f, startAngle, endAngle, true);
    g.setColour (kTrack);
    g.strokePath (track, juce::PathStrokeType (3.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

    // value arc (blue)
    juce::Path val;
    val.addCentredArc (cx, cy, radius, radius, 0.0f, startAngle, angle, true);
    g.setColour (kAccent);
    g.strokePath (val, juce::PathStrokeType (3.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

    // pointer
    juce::Path ptr;
    auto pl = rInner * 0.9f;
    ptr.startNewSubPath (cx, cy);
    ptr.lineTo (cx + pl * std::cos (angle - juce::MathConstants<float>::halfPi),
                cy + pl * std::sin (angle - juce::MathConstants<float>::halfPi));
    g.setColour (kAccentD);
    g.strokePath (ptr, juce::PathStrokeType (2.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    g.setColour (kAccent);
    g.fillEllipse (cx - 3.0f, cy - 3.0f, 6.0f, 6.0f);
}

void NexusLookAndFeel::drawComboBox (juce::Graphics& g, int width, int height, bool,
                                     int, int, int, int, juce::ComboBox& box)
{
    auto b = juce::Rectangle<float> (0, 0, (float) width, (float) height);
    g.setColour (kLcdBg);
    g.fillRoundedRectangle (b, 5.0f);
    g.setColour (kAccent.withAlpha (0.7f));
    g.drawRoundedRectangle (b.reduced (0.5f), 5.0f, 1.0f);

    // caret
    juce::Path tri;
    float cxp = width - 14.0f, cyp = height * 0.5f;
    tri.addTriangle (cxp, cyp + 3.0f, cxp + 7.0f, cyp - 3.0f, cxp - 7.0f, cyp - 3.0f);
    g.setColour (kLcdTxt.withAlpha (0.8f));
    g.fillPath (tri);
    juce::ignoreUnused (box);
}

// =====================================================================

DarkSynthEditor::Ctl& DarkSynthEditor::addKnob (const juce::String& id, const juce::String& name)
{
    auto* c = new Ctl();
    c->slider.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    c->slider.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 64, 16);
    c->slider.setColour (juce::Slider::textBoxTextColourId, kAccentD);
    c->slider.setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
    c->slider.setLookAndFeel (&lnf);
    addAndMakeVisible (c->slider);

    c->label.setText (name, juce::dontSendNotification);
    c->label.setJustificationType (juce::Justification::centred);
    c->label.setColour (juce::Label::textColourId, kMuted);
    c->label.setLookAndFeel (&lnf);
    addAndMakeVisible (c->label);

    c->att = std::make_unique<SliderAtt> (proc.apvts, id, c->slider);
    knobs.add (c);
    return *c;
}

DarkSynthEditor::DarkSynthEditor (DarkSynthProcessor& p)
    : AudioProcessorEditor (&p), proc (p)
{
    setLookAndFeel (&lnf);

    auto setupCombo = [this] (juce::ComboBox& box, const juce::StringArray& items)
    {
        box.addItemList (items, 1);
        box.setColour (juce::ComboBox::backgroundColourId, kLcdBg);
        box.setColour (juce::ComboBox::textColourId, kLcdTxt);
        box.setColour (juce::ComboBox::outlineColourId, kAccent);
        box.setColour (juce::ComboBox::arrowColourId, kLcdTxt);
        box.setLookAndFeel (&lnf);
        addAndMakeVisible (box);
    };

    setupCombo (engineBox, { "Subtractive", "FM", "Wavetable" });
    setupCombo (osc1Box,   { "Sine", "Saw", "Square", "Triangle" });
    setupCombo (osc2Box,   { "Sine", "Saw", "Square", "Triangle" });
    setupCombo (filterBox, { "LowPass", "HighPass", "BandPass" });

    engineAtt = std::make_unique<ComboAtt> (proc.apvts, "engine", engineBox);
    osc1Att   = std::make_unique<ComboAtt> (proc.apvts, "osc1Wave", osc1Box);
    osc2Att   = std::make_unique<ComboAtt> (proc.apvts, "osc2Wave", osc2Box);
    filterAtt = std::make_unique<ComboAtt> (proc.apvts, "filterType", filterBox);

    addKnob ("osc1Detune", "DET 1");
    addKnob ("osc2Detune", "DET 2");
    addKnob ("oscMix",     "MIX");
    addKnob ("fmRatio",    "RATIO");
    addKnob ("fmIndex",    "INDEX");
    addKnob ("wavePos",    "WAVE");
    addKnob ("cutoff",     "CUTOFF");
    addKnob ("resonance",  "RESO");
    addKnob ("attack",     "ATK");
    addKnob ("decay",      "DEC");
    addKnob ("sustain",    "SUS");
    addKnob ("release",    "REL");
    addKnob ("drive",      "DRIVE");
    addKnob ("delayMix",   "DLY MIX");
    addKnob ("delayTime",  "DLY TIME");
    addKnob ("delayFeedback", "DLY FBK");
    addKnob ("reverbMix",  "VERB");
    addKnob ("master",     "MASTER");

    setSize (820, 560);
}

DarkSynthEditor::~DarkSynthEditor()
{
    for (auto* c : knobs) { c->slider.setLookAndFeel (nullptr); c->label.setLookAndFeel (nullptr); }
    engineBox.setLookAndFeel (nullptr);
    osc1Box.setLookAndFeel (nullptr);
    osc2Box.setLookAndFeel (nullptr);
    filterBox.setLookAndFeel (nullptr);
    setLookAndFeel (nullptr);
}

void DarkSynthEditor::paint (juce::Graphics& g)
{
    // brushed light-metal background
    g.setGradientFill (juce::ColourGradient (kBgTop, 0, 0, kBgBot, 0, (float) getHeight(), false));
    g.fillAll();

    // outer chassis
    auto chassis = getLocalBounds().reduced (8).toFloat();
    g.setColour (kPanel);
    g.fillRoundedRectangle (chassis, 14.0f);
    g.setColour (kPanelEd);
    g.drawRoundedRectangle (chassis.reduced (0.5f), 14.0f, 1.2f);

    // section panels behind knob rows
    static const char* rowTitles[3] = { "OSCILLATOR", "FILTER \u00b7 ENVELOPE", "FX \u00b7 OUTPUT" };
    for (int i = 0; i < 3; ++i)
    {
        if (rowPanels[i].isEmpty()) continue;
        auto r = rowPanels[i].toFloat();
        g.setColour (juce::Colours::white.withAlpha (0.55f));
        g.fillRoundedRectangle (r, 9.0f);
        g.setColour (kPanelEd.withAlpha (0.8f));
        g.drawRoundedRectangle (r.reduced (0.5f), 9.0f, 1.0f);
        g.setColour (kMuted);
        g.setFont (juce::Font (9.0f, juce::Font::bold));
        g.drawText (rowTitles[i], rowPanels[i].getX() + 10, rowPanels[i].getY() + 4, 200, 12,
                    juce::Justification::left);
    }

    // title
    g.setColour (kText);
    g.setFont (juce::Font (28.0f, juce::Font::bold));
    g.drawText (" o1 DARK SYNTH", 26, 16, 460, 32, juce::Justification::left);
    g.setColour (kAccent);
    g.setFont (juce::Font (28.0f, juce::Font::bold));
    g.drawText ("1", 26, 16, 20, 32, juce::Justification::left);
    g.setColour (kAccent);
    g.setFont (juce::Font (13.0f, juce::Font::bold));
    g.drawText ("\u00b2", 300, 14, 20, 18, juce::Justification::left);

    g.setColour (kMuted);
    g.setFont (juce::Font (10.0f));
    g.drawText ("STEAM Engine\u2122 \u00b7 Software Synthesis", 27, 46, 400, 16, juce::Justification::left);
}

void DarkSynthEditor::resized()
{
    auto area = getLocalBounds().reduced (24);
    area.removeFromTop (56);

    auto comboRow = area.removeFromTop (34);
    engineBox.setBounds (comboRow.removeFromLeft (160).reduced (2));
    comboRow.removeFromLeft (10);
    osc1Box.setBounds (comboRow.removeFromLeft (120).reduced (2));
    osc2Box.setBounds (comboRow.removeFromLeft (120).reduced (2));
    filterBox.setBounds (comboRow.removeFromLeft (120).reduced (2));

    area.removeFromTop (12);

    const int perRow = 6;
    const int kw = area.getWidth() / perRow;
    const int kh = 128;
    for (int i = 0; i < knobs.size(); ++i)
    {
        int row = i / perRow, col = i % perRow;
        juce::Rectangle<int> cell (area.getX() + col * kw, area.getY() + row * kh, kw, kh);
        // record row panel bounds
        if (col == 0 && row < 3)
            rowPanels[row] = juce::Rectangle<int> (area.getX() - 6, area.getY() + row * kh - 2,
                                                   kw * perRow + 12, kh - 6);
        cell.removeFromTop (16); // room for section title
        knobs[i]->label.setBounds (cell.removeFromTop (14));
        knobs[i]->slider.setBounds (cell.reduced (6));
    }
    repaint();
}
