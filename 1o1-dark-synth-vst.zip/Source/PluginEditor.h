#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

// White glossy "Nexus"-style look: light knob bodies with a bright blue value arc.
class NexusLookAndFeel : public juce::LookAndFeel_V4
{
public:
    NexusLookAndFeel();
    void drawRotarySlider (juce::Graphics&, int x, int y, int w, int h,
                           float pos, float startAngle, float endAngle,
                           juce::Slider&) override;
    void drawComboBox (juce::Graphics&, int width, int height, bool isDown,
                       int buttonX, int buttonY, int buttonW, int buttonH,
                       juce::ComboBox&) override;
    juce::Font getComboBoxFont (juce::ComboBox&) override;
    juce::Font getLabelFont (juce::Label&) override;
};

class DarkSynthEditor : public juce::AudioProcessorEditor
{
public:
    explicit DarkSynthEditor (DarkSynthProcessor&);
    ~DarkSynthEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    using SliderAtt = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ComboAtt  = juce::AudioProcessorValueTreeState::ComboBoxAttachment;

    struct Ctl
    {
        juce::Slider slider;
        juce::Label  label;
        std::unique_ptr<SliderAtt> att;
    };

    Ctl& addKnob (const juce::String& id, const juce::String& name);

    DarkSynthProcessor& proc;
    juce::OwnedArray<Ctl> knobs;

    juce::ComboBox engineBox, osc1Box, osc2Box, filterBox;
    std::unique_ptr<ComboAtt> engineAtt, osc1Att, osc2Att, filterAtt;

    NexusLookAndFeel lnf;
    juce::Rectangle<int> rowPanels[3];

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (DarkSynthEditor)
};
