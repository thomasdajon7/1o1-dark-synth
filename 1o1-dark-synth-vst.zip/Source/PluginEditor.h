#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class DarkSynthEditor : public juce::AudioProcessorEditor
{
public:
    explicit DarkSynthEditor (DarkSynthProcessor&);
    ~DarkSynthEditor() override = default;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    using SliderAtt = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ComboAtt  = juce::AudioProcessorValueTreeState::ComboBoxAttachment;

    struct Ctl
    {
        juce::Slider slider;
        juce::Label  label;
        std::unique_ptr<SliderAtt> att;
    };

    Ctl& addKnob (const juce::String& id, const juce::String& name);

    DarkSynthProcessor& proc;
    juce::OwnedArray<Ctl> knobs;

    juce::ComboBox engineBox, osc1Box, osc2Box, filterBox;
    std::unique_ptr<ComboAtt> engineAtt, osc1Att, osc2Att, filterAtt;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (DarkSynthEditor)
};
