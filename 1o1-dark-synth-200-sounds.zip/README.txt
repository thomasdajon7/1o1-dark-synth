1o1 DARK SYNTH - 200 SOUND EXPANSION PACK
==========================================
200 factory presets across Bells, Arps, Keys, Vox, Choir, Strings, Lead & Piano.

These sounds are BUILT INTO the 1o1 DARK SYNTH plugin - just open the LCD preset
browser inside the plugin, pick a category, and click a sound to load it.

This pack (presets.json) is a machine-readable reference of every preset and its
parameter values. Get the plugin at https://1o1synth.com
