#include "PluginProcessor.h"
#include "PluginEditor.h"
#include "SynthVoice.h"

DarkSynthProcessor::DarkSynthProcessor()
    : AudioProcessor (BusesProperties().withOutput ("Output", juce::AudioChannelSet::stereo(), true))
{
    synth.addSound (new SteamSound());
    for (int i = 0; i < 16; ++i)
        synth.addVoice (new SteamVoice (apvts));
}

juce::AudioProcessorValueTreeState::ParameterLayout DarkSynthProcessor::createLayout()
{
    using P = juce::AudioParameterFloat;
    using C = juce::AudioParameterChoice;
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> p;

    p.push_back (std::make_unique<C> ("engine", "Engine",
        juce::StringArray { "Subtractive", "FM", "Wavetable" }, 0));
    p.push_back (std::make_unique<C> ("osc1Wave", "Osc1 Wave",
        juce::StringArray { "Sine", "Saw", "Square", "Triangle" }, 1));
    p.push_back (std::make_unique<C> ("osc2Wave", "Osc2 Wave",
        juce::StringArray { "Sine", "Saw", "Square", "Triangle" }, 1));
    p.push_back (std::make_unique<C> ("filterType", "Filter Type",
        juce::StringArray { "LowPass", "HighPass", "BandPass" }, 0));

    p.push_back (std::make_unique<P> ("osc1Detune", "Osc1 Detune", juce::NormalisableRange<float> (-24, 24, 1), 0));
    p.push_back (std::make_unique<P> ("osc2Detune", "Osc2 Detune", juce::NormalisableRange<float> (-24, 24, 1), -7));
    p.push_back (std::make_unique<P> ("oscMix", "Osc Mix", 0.0f, 1.0f, 0.5f));
    p.push_back (std::make_unique<P> ("fmRatio", "FM Ratio", juce::NormalisableRange<float> (0.5f, 8.0f, 0.5f), 2.0f));
    p.push_back (std::make_unique<P> ("fmIndex", "FM Index", juce::NormalisableRange<float> (0.0f, 12.0f, 0.01f), 2.0f));
    p.push_back (std::make_unique<P> ("wavePos", "Wave Position", 0.0f, 1.0f, 0.5f));

    p.push_back (std::make_unique<P> ("cutoff", "Cutoff", juce::NormalisableRange<float> (40, 12000, 1, 0.3f), 2400));
    p.push_back (std::make_unique<P> ("resonance", "Resonance", juce::NormalisableRange<float> (0.1f, 18.0f, 0.1f), 4.0f));

    p.push_back (std::make_unique<P> ("attack", "Attack", juce::NormalisableRange<float> (0.001f, 3.0f, 0.001f, 0.4f), 0.01f));
    p.push_back (std::make_unique<P> ("decay", "Decay", juce::NormalisableRange<float> (0.001f, 3.0f, 0.001f, 0.4f), 0.2f));
    p.push_back (std::make_unique<P> ("sustain", "Sustain", 0.0f, 1.0f, 0.7f));
    p.push_back (std::make_unique<P> ("release", "Release", juce::NormalisableRange<float> (0.001f, 4.0f, 0.001f, 0.4f), 0.3f));

    p.push_back (std::make_unique<P> ("drive", "Drive", 0.0f, 1.0f, 0.0f));
    p.push_back (std::make_unique<P> ("delayMix", "Delay Mix", 0.0f, 1.0f, 0.1f));
    p.push_back (std::make_unique<P> ("delayTime", "Delay Time", 0.01f, 1.0f, 0.3f));
    p.push_back (std::make_unique<P> ("delayFeedback", "Delay Fbk", 0.0f, 0.9f, 0.3f));
    p.push_back (std::make_unique<P> ("reverbMix", "Reverb", 0.0f, 1.0f, 0.15f));
    p.push_back (std::make_unique<P> ("master", "Master", 0.0f, 1.0f, 0.7f));

    return { p.begin(), p.end() };
}

void DarkSynthProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    currentSr = sampleRate;
    synth.setCurrentPlaybackSampleRate (sampleRate);
    for (int i = 0; i < synth.getNumVoices(); ++i)
        if (auto* v = dynamic_cast<SteamVoice*> (synth.getVoice (i)))
            v->prepare (sampleRate, samplesPerBlock, 2);

    juce::dsp::ProcessSpec spec { sampleRate, (juce::uint32) samplesPerBlock, 2 };
    delayLine.prepare (spec);
    reverb.prepare (spec);
    distortion.functionToUse = [] (float x) { return std::tanh (x); };
}

bool DarkSynthProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    return layouts.getMainOutputChannelSet() == juce::AudioChannelSet::stereo();
}

void DarkSynthProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    buffer.clear();

    // Merge on-screen keyboard notes into the incoming MIDI stream
    keyboardState.processNextMidiBuffer (midi, 0, buffer.getNumSamples(), true);

    synth.renderNextBlock (buffer, midi, 0, buffer.getNumSamples());

    const float drive     = *apvts.getRawParameterValue ("drive");
    const float reverbMix = *apvts.getRawParameterValue ("reverbMix");
    const float master    = *apvts.getRawParameterValue ("master");

    juce::Reverb::Parameters rp;
    rp.roomSize = 0.7f; rp.damping = 0.4f; rp.width = 1.0f;
    rp.wetLevel = reverbMix; rp.dryLevel = 1.0f - reverbMix * 0.5f;
    reverb.setParameters (rp);

    const int n = buffer.getNumSamples();
    const int nch = buffer.getNumChannels();

    for (int ch = 0; ch < nch; ++ch)
    {
        auto* d = buffer.getWritePointer (ch);
        for (int i = 0; i < n; ++i)
        {
            float x = d[i];

            // Distortion (parallel mix)
            if (drive > 0.0f)
            {
                float wet = std::tanh (x * (1.0f + drive * 8.0f));
                x = x * (1.0f - drive) + wet * drive;
            }

            d[i] = x * master;
        }
    }

    // Reverb (block based)
    juce::dsp::AudioBlock<float> block (buffer);
    juce::dsp::ProcessContextReplacing<float> ctx (block);
    reverb.process (ctx);
}

juce::AudioProcessorEditor* DarkSynthProcessor::createEditor()
{
    return new DarkSynthEditor (*this);
}

void DarkSynthProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    if (auto state = apvts.copyState().createXml())
        copyXmlToBinary (*state, destData);
}

void DarkSynthProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    if (auto xml = getXmlFromBinary (data, sizeInBytes))
        apvts.replaceState (juce::ValueTree::fromXml (*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new DarkSynthProcessor();
}
