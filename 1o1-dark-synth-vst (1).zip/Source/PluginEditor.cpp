#include "PluginEditor.h"
#include "PresetBank.h"

// ---- Nexus palette ----
static const juce::Colour kBgTop   { 0xffeef1f5 };
static const juce::Colour kBgBot   { 0xffcfd5dd };
static const juce::Colour kPanel   { 0xfff8fafc };
static const juce::Colour kPanelEd { 0xffbcc4cd };
static const juce::Colour kAccent  { 0xff1f8ecd };
static const juce::Colour kAccentD { 0xff0f5f88 };
static const juce::Colour kKnobHi  { 0xfffdfefe };
static const juce::Colour kKnobLo  { 0xffdae0e7 };
static const juce::Colour kTrack   { 0xffc6ccd4 };
static const juce::Colour kText    { 0xff33404b };
static const juce::Colour kMuted   { 0xff8a97a3 };
static const juce::Colour kLcdBg   { 0xff072433 };
static const juce::Colour kLcdTxt  { 0xff7fe3ff };
static const juce::Colour kLcdSel  { 0xff1f8ecd };

// ---- built-in presets: see PresetBank.h (200 factory sounds) ----

// ================= LookAndFeel =================
NexusLookAndFeel::NexusLookAndFeel()
{
    setColour (juce::Slider::textBoxTextColourId, kAccentD);
    setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
    setColour (juce::PopupMenu::backgroundColourId, kLcdBg);
    setColour (juce::PopupMenu::textColourId, kLcdTxt);
    setColour (juce::PopupMenu::highlightedBackgroundColourId, kAccent);
}
juce::Font NexusLookAndFeel::getComboBoxFont (juce::ComboBox&) { return juce::Font (juce::Font::getDefaultMonospacedFontName(), 12.5f, juce::Font::bold); }
juce::Font NexusLookAndFeel::getLabelFont (juce::Label&) { return juce::Font (9.5f, juce::Font::bold); }

void NexusLookAndFeel::drawRotarySlider (juce::Graphics& g, int x, int y, int w, int h,
                                         float pos, float startAngle, float endAngle, juce::Slider&)
{
    auto b = juce::Rectangle<float> ((float) x, (float) y, (float) w, (float) h).reduced (5.0f);
    auto radius = juce::jmin (b.getWidth(), b.getHeight()) * 0.5f;
    auto cx = b.getCentreX(), cy = b.getCentreY();
    auto angle = startAngle + pos * (endAngle - startAngle);
    auto rInner = radius * 0.6f;

    g.setColour (juce::Colours::black.withAlpha (0.12f));
    g.fillEllipse (cx - rInner, cy - rInner + 2.0f, rInner * 2.0f, rInner * 2.0f);
    juce::ColourGradient grad (kKnobHi, cx, cy - rInner, kKnobLo, cx, cy + rInner, false);
    g.setGradientFill (grad);
    g.fillEllipse (cx - rInner, cy - rInner, rInner * 2.0f, rInner * 2.0f);
    g.setColour (kPanelEd);
    g.drawEllipse (cx - rInner, cy - rInner, rInner * 2.0f, rInner * 2.0f, 1.0f);

    juce::Path track; track.addCentredArc (cx, cy, radius, radius, 0.0f, startAngle, endAngle, true);
    g.setColour (kTrack);
    g.strokePath (track, juce::PathStrokeType (2.6f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    juce::Path val; val.addCentredArc (cx, cy, radius, radius, 0.0f, startAngle, angle, true);
    g.setColour (kAccent);
    g.strokePath (val, juce::PathStrokeType (2.6f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

    juce::Path ptr; auto pl = rInner * 0.88f;
    ptr.startNewSubPath (cx, cy);
    ptr.lineTo (cx + pl * std::cos (angle - juce::MathConstants<float>::halfPi),
                cy + pl * std::sin (angle - juce::MathConstants<float>::halfPi));
    g.setColour (kAccentD);
    g.strokePath (ptr, juce::PathStrokeType (2.2f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    g.setColour (kAccent);
    g.fillEllipse (cx - 2.6f, cy - 2.6f, 5.2f, 5.2f);
}

void NexusLookAndFeel::drawComboBox (juce::Graphics& g, int width, int height, bool,
                                     int, int, int, int, juce::ComboBox&)
{
    auto b = juce::Rectangle<float> (0, 0, (float) width, (float) height);
    g.setColour (kLcdBg); g.fillRoundedRectangle (b, 5.0f);
    g.setColour (kAccent.withAlpha (0.7f)); g.drawRoundedRectangle (b.reduced (0.5f), 5.0f, 1.0f);
    juce::Path tri; float cxp = width - 13.0f, cyp = height * 0.5f;
    tri.addTriangle (cxp, cyp + 3.0f, cxp + 6.0f, cyp - 3.0f, cxp - 6.0f, cyp - 3.0f);
    g.setColour (kLcdTxt.withAlpha (0.8f)); g.fillPath (tri);
}

// ================= List model =================
void LcdListModel::paintListBoxItem (int row, juce::Graphics& g, int w, int h, bool sel)
{
    if (! rowText) return;
    if (sel) { g.setColour (kLcdSel); g.fillRect (0, 0, w, h); g.setColour (juce::Colours::white); }
    else g.setColour (kLcdTxt);
    g.setFont (juce::Font (juce::Font::getDefaultMonospacedFontName(), 12.0f, juce::Font::plain));
    g.drawText (rowText (row), 8, 0, w - 10, h, juce::Justification::centredLeft);
}

// ================= Editor =================
void DarkSynthEditor::addKnob (const juce::String& id, const juce::String& name)
{
    auto* c = new Ctl();
    c->slider.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    c->slider.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 58, 15);
    c->slider.setColour (juce::Slider::textBoxTextColourId, kAccentD);
    c->slider.setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
    c->slider.setLookAndFeel (&lnf);
    addAndMakeVisible (c->slider);
    c->label.setText (name, juce::dontSendNotification);
    c->label.setJustificationType (juce::Justification::centred);
    c->label.setColour (juce::Label::textColourId, kMuted);
    c->label.setLookAndFeel (&lnf);
    addAndMakeVisible (c->label);
    c->att = std::make_unique<SliderAtt> (proc.apvts, id, c->slider);
    knobs.add (c);
}

void DarkSynthEditor::setParam (const juce::String& id, float actual)
{
    if (auto* p = proc.apvts.getParameter (id))
        p->setValueNotifyingHost (p->convertTo0to1 (actual));
}

void DarkSynthEditor::rebuildFiltered()
{
    filtered.clear();
    const auto& all = presets();
    for (int i = 0; i < (int) all.size(); ++i)
        if (all[(size_t) i].cat == categories[selectedCat])
            filtered.add (i);
    presetBox.updateContent();
    presetBox.deselectAllRows();
    repaint();
}

void DarkSynthEditor::applyPreset (int filteredRow)
{
    if (filteredRow < 0 || filteredRow >= filtered.size()) return;
    const auto& pr = presets()[(size_t) filtered[filteredRow]];
    // reset a baseline so unspecified params return to sane defaults
    for (auto& kv : pr.p) setParam (kv.first, kv.second);
    currentPresetName = pr.name;
    repaint();
}

DarkSynthEditor::DarkSynthEditor (DarkSynthProcessor& p)
    : AudioProcessorEditor (&p), proc (p)
{
    setLookAndFeel (&lnf);

    auto setupCombo = [this] (juce::ComboBox& box, const juce::StringArray& items)
    {
        box.addItemList (items, 1);
        box.setColour (juce::ComboBox::backgroundColourId, kLcdBg);
        box.setColour (juce::ComboBox::textColourId, kLcdTxt);
        box.setColour (juce::ComboBox::outlineColourId, kAccent);
        box.setColour (juce::ComboBox::arrowColourId, kLcdTxt);
        box.setLookAndFeel (&lnf);
        addAndMakeVisible (box);
    };
    setupCombo (engineBox, { "Subtractive", "FM", "Wavetable" });
    setupCombo (osc1Box,   { "Sine", "Saw", "Square", "Triangle" });
    setupCombo (osc2Box,   { "Sine", "Saw", "Square", "Triangle" });
    setupCombo (filterBox, { "LowPass", "HighPass", "BandPass" });
    engineAtt = std::make_unique<ComboAtt> (proc.apvts, "engine", engineBox);
    osc1Att   = std::make_unique<ComboAtt> (proc.apvts, "osc1Wave", osc1Box);
    osc2Att   = std::make_unique<ComboAtt> (proc.apvts, "osc2Wave", osc2Box);
    filterAtt = std::make_unique<ComboAtt> (proc.apvts, "filterType", filterBox);

    // FILTER MODIFIER
    addKnob ("cutoff", "CUTOFF"); addKnob ("resonance", "RESO");
    // OSCILLATOR
    addKnob ("osc1Detune", "DET 1"); addKnob ("osc2Detune", "DET 2");
    addKnob ("oscMix", "MIX"); addKnob ("wavePos", "WAVE");
    // AMP MODIFIER
    addKnob ("attack", "ATK"); addKnob ("decay", "DEC");
    addKnob ("sustain", "SUS"); addKnob ("release", "REL");
    // FM
    addKnob ("fmRatio", "RATIO"); addKnob ("fmIndex", "INDEX");
    // BOTTOM
    addKnob ("drive", "DRIVE");
    addKnob ("reverbMix", "VERB"); addKnob ("master", "MASTER");

    // categories
    for (auto& pr : presets())
        if (! categories.contains (pr.cat)) categories.add (pr.cat);

    catModel.numRows = [this] { return categories.size(); };
    catModel.rowText = [this] (int r) { return categories[r]; };
    catModel.onSelect = [this] (int r) { if (r >= 0 && r < categories.size()) { selectedCat = r; catBox.selectRow (r); rebuildFiltered(); } };
    catBox.setModel (&catModel);
    catBox.setColour (juce::ListBox::backgroundColourId, kLcdBg);
    catBox.setRowHeight (22);
    addAndMakeVisible (catBox);

    presetModel.numRows = [this] { return filtered.size(); };
    presetModel.rowText = [this] (int r) { return (r >= 0 && r < filtered.size()) ? presets()[(size_t) filtered[r]].name : juce::String(); };
    presetModel.onSelect = [this] (int r) { presetBox.selectRow (r); applyPreset (r); };
    presetBox.setModel (&presetModel);
    presetBox.setColour (juce::ListBox::backgroundColourId, kLcdBg);
    presetBox.setRowHeight (22);
    addAndMakeVisible (presetBox);

    catBox.selectRow (0);
    rebuildFiltered();

    // On-screen keyboard
    keyboard.setLowestVisibleKey (36); // C2
    keyboard.setKeyWidth (22.0f);
    keyboard.setColour (juce::MidiKeyboardComponent::whiteNoteColourId, juce::Colour (0xfff8fafc));
    keyboard.setColour (juce::MidiKeyboardComponent::blackNoteColourId, juce::Colour (0xff33404b));
    keyboard.setColour (juce::MidiKeyboardComponent::keySeparatorLineColourId, juce::Colour (0xffbcc4cd));
    keyboard.setColour (juce::MidiKeyboardComponent::keyDownOverlayColourId, juce::Colour (0xff1f8ecd).withAlpha (0.7f));
    keyboard.setColour (juce::MidiKeyboardComponent::mouseOverKeyOverlayColourId, juce::Colour (0xff1f8ecd).withAlpha (0.35f));
    keyboard.setColour (juce::MidiKeyboardComponent::shadowColourId, juce::Colours::black.withAlpha (0.15f));
    keyboard.setColour (juce::MidiKeyboardComponent::upDownButtonBackgroundColourId, juce::Colour (0xff072433));
    keyboard.setColour (juce::MidiKeyboardComponent::upDownButtonArrowColourId, juce::Colour (0xff7fe3ff));
    addAndMakeVisible (keyboard);

    setSize (940, 730);
}

DarkSynthEditor::~DarkSynthEditor()
{
    for (auto* c : knobs) { c->slider.setLookAndFeel (nullptr); c->label.setLookAndFeel (nullptr); }
    engineBox.setLookAndFeel (nullptr); osc1Box.setLookAndFeel (nullptr);
    osc2Box.setLookAndFeel (nullptr); filterBox.setLookAndFeel (nullptr);
    catBox.setModel (nullptr); presetBox.setModel (nullptr);
    setLookAndFeel (nullptr);
}

static void drawPanel (juce::Graphics& g, juce::Rectangle<int> r, const juce::String& title)
{
    auto rf = r.toFloat();
    g.setColour (juce::Colours::white.withAlpha (0.6f));
    g.fillRoundedRectangle (rf, 9.0f);
    g.setColour (kPanelEd);
    g.drawRoundedRectangle (rf.reduced (0.5f), 9.0f, 1.0f);
    g.setColour (kAccent);
    g.setFont (juce::Font (9.5f, juce::Font::bold));
    g.drawText (title, r.getX() + 12, r.getY() + 6, r.getWidth() - 20, 12, juce::Justification::left);
}

void DarkSynthEditor::paint (juce::Graphics& g)
{
    g.setGradientFill (juce::ColourGradient (kBgTop, 0, 0, kBgBot, 0, (float) getHeight(), false));
    g.fillAll();
    auto chassis = getLocalBounds().reduced (7).toFloat();
    g.setColour (kPanel); g.fillRoundedRectangle (chassis, 16.0f);
    g.setColour (kPanelEd); g.drawRoundedRectangle (chassis.reduced (0.5f), 16.0f, 1.4f);

    // screws
    g.setColour (kPanelEd.withAlpha (0.7f));
    for (auto pt : { juce::Point<float> (24, 24), { (float) getWidth() - 24, 24.0f },
                     { 24.0f, (float) getHeight() - 24 }, { (float) getWidth() - 24, (float) getHeight() - 24 } })
        g.fillEllipse (pt.x - 4, pt.y - 4, 8, 8);

    // title
    g.setColour (kText); g.setFont (juce::Font (24.0f, juce::Font::bold));
    g.drawText (" o1 DARK SYNTH", 40, 16, 400, 30, juce::Justification::left);
    g.setColour (kAccent); g.setFont (juce::Font (24.0f, juce::Font::bold));
    g.drawText ("1", 40, 16, 20, 30, juce::Justification::left);
    g.setFont (juce::Font (12.0f, juce::Font::bold));
    g.drawText (juce::String::fromUTF8 ("\xC2\xB2"), 258, 14, 16, 16, juce::Justification::left);

    // panels
    drawPanel (g, rFilter, "FILTER MODIFIER");
    drawPanel (g, rOsc,    "OSCILLATOR");
    drawPanel (g, rAmp,    "AMP MODIFIER");
    drawPanel (g, rFm,     "FM ENGINE");
    drawPanel (g, rBottom, "MASTER \xC2\xB7 FX \xC2\xB7 OUTPUT");

    // LCD frame
    auto lf = rLcd.toFloat();
    g.setColour (juce::Colours::black.withAlpha (0.25f));
    g.fillRoundedRectangle (lf.expanded (4.0f), 10.0f);
    g.setColour (kLcdBg); g.fillRoundedRectangle (lf, 8.0f);
    g.setColour (kAccent); g.drawRoundedRectangle (lf.reduced (0.5f), 8.0f, 1.2f);
    // LCD header (current preset)
    g.setColour (kLcdTxt); g.setFont (juce::Font (juce::Font::getDefaultMonospacedFontName(), 15.0f, juce::Font::bold));
    g.drawText (currentPresetName, rLcd.getX() + 12, rLcd.getY() + 8, rLcd.getWidth() - 24, 20, juce::Justification::centredLeft);
    g.setColour (kAccent.withAlpha (0.4f));
    g.drawHorizontalLine (rLcd.getY() + 32, (float) rLcd.getX() + 8, (float) rLcd.getRight() - 8);
}

void DarkSynthEditor::layoutKnobs (juce::Rectangle<int> area, int start, int count, int cols)
{
    area.removeFromTop (20); // panel title space
    const int rows = (count + cols - 1) / cols;
    const int cw = area.getWidth() / cols;
    const int ch = area.getHeight() / rows;
    for (int i = 0; i < count; ++i)
    {
        int idx = start + i, r = i / cols, c = i % cols;
        juce::Rectangle<int> cell (area.getX() + c * cw, area.getY() + r * ch, cw, ch);
        knobs[idx]->label.setBounds (cell.removeFromTop (13));
        knobs[idx]->slider.setBounds (cell.reduced (5));
    }
}

void DarkSynthEditor::resized()
{
    auto area = getLocalBounds().reduced (24);
    area.removeFromTop (34); // header

    auto comboRow = area.removeFromTop (30);
    engineBox.setBounds (comboRow.removeFromLeft (200).reduced (2));
    comboRow.removeFromLeft (8);
    osc1Box.setBounds (comboRow.removeFromLeft (150).reduced (2));
    osc2Box.setBounds (comboRow.removeFromLeft (150).reduced (2));
    filterBox.setBounds (comboRow.removeFromLeft (150).reduced (2));
    area.removeFromTop (10);

    // On-screen keyboard pinned to the very bottom
    keyboard.setBounds (area.removeFromBottom (76));
    area.removeFromBottom (12);

    auto bottom = area.removeFromBottom (150);
    rBottom = bottom;
    area.removeFromBottom (12);

    const int sideW = 268;
    auto left = area.removeFromLeft (sideW);
    auto right = area.removeFromRight (sideW);
    area.removeFromLeft (14); area.removeFromRight (14);
    rLcd = area;

    rFilter = left.removeFromTop (138);
    left.removeFromTop (10);
    rOsc = left;

    rAmp = right.removeFromTop (208);
    right.removeFromTop (10);
    rFm = right;

    layoutKnobs (rFilter, 0, 2, 2);
    layoutKnobs (rOsc,    2, 4, 2);
    layoutKnobs (rAmp,    6, 4, 2);
    layoutKnobs (rFm,    10, 2, 2);
    layoutKnobs (rBottom,12, 3, 3);

    auto lcd = rLcd.reduced (10);
    lcd.removeFromTop (30); // header line
    auto cat = lcd.removeFromLeft (96);
    lcd.removeFromLeft (6);
    catBox.setBounds (cat);
    presetBox.setBounds (lcd);
}
